﻿using System;

namespace _31GennaioEs2;

internal class Program
{
    static void Main(string[] args)
    {
        //chiedo all'utente quanti elementi deve contenere l'array
        Console.Write("Quanti elementi deve contenere l'array?\n");
        //converto la stringa in integer
        int NumeroNomi = Convert.ToInt16(Console.ReadLine());

        //creo un nuovo array 
        string[] nomi = new string[NumeroNomi];

        //chiede al utente di inserire i nomi
        for (int i = 0;i < NumeroNomi; i++)
        {
            Console.Write($"Inserisci nome {i + 1}: ");
            nomi[i] = Console.ReadLine().ToUpper();
        }

        //Console.WriteLine(string.Join(", ", nomi));

        Console.WriteLine("Inserisci il nome da cercare: \n");
        string Query = Console.ReadLine().ToUpper();

        for (int i = 0; i < nomi.Length; i++)
        {
            if(Query == nomi[i])
            {
                Console.WriteLine($"{nomi[i]} is in the array");
            }
            else
            {
                Console.WriteLine($"Sorry, {nomi[i]} is NOT in the array");
            }
        }

        Console.ReadLine();
    }
}