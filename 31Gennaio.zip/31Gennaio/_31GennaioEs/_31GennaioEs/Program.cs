﻿using System;

namespace _31GennaioEs;

internal class Program
{
    static void Main(string[] args)
    {
        ContoCorrente conto1 = new ContoCorrente();
        conto1.Nome = "Ebby";
        conto1.Cognome = "Chakkungal";
        conto1.NumeroConto = 12345;
        conto1.Saldo = 2000;

        //qui apre il conto
        Console.WriteLine(conto1.ApriConto());

        //chiede se fare un prelievo o un versamento
        Console.WriteLine("Vuoi fare un prelievo o un versamento?\n (Scrivi p per prelievo e v per versamento)");
        
        string azione = Console.ReadLine();

        if (azione == "v"|| azione == "V")
        {
            //qui fa il versamento
            Console.WriteLine("Quanto vuoi versare? ");
            conto1.SommaVersamento = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine(conto1.Versamento());
        }
        else if (azione == "p" || azione == "P")
        {
            //qui fa il prelievo
            Console.WriteLine("Quanto vuoi prelevare? ");
            conto1.SommaPrelievo = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine(conto1.Prelievo());
        }
        else
        {
            Console.WriteLine("Carattere non valido");
        }


        

      
        //qui apre il conto aggiornato
        Console.WriteLine(conto1.ApriConto());

        Console.ReadLine();
    }
}

