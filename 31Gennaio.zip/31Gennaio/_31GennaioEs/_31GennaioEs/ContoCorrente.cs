﻿using System;
namespace _31GennaioEs
{
	public class ContoCorrente
	{
		//per inserire i dati
		public string Nome { get; set; }
        public string Cognome { get; set; }
		public int NumeroConto { get; set; }
		public int Saldo { get; set; }

		//per chiedere i dati al utente
		public int SommaVersamento { get; set; }
        public int SommaPrelievo { get; set; }

		//metodo per aprire il conto
        public string ApriConto()
		{
			return $"{Nome} {Cognome} \n N° Contocorrente: {NumeroConto} \n Saldo disponibile: {Saldo}";
		}

		//metodo per fare il versamento
		public string Versamento()
		{
			if (SommaVersamento >= 1000)
			{
				Saldo += SommaVersamento;
				return "Versamento effetuato!";
			}
			else
			{
				return "La somma da versare deve essere superiore a 1000";
			}
			
		}

		//metodo per fare il prelievo
		public string Prelievo()
		{
			Saldo -= SommaPrelievo;
			return "Prelievo effetuato!";
		}

		
    }
}

