﻿using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace _31GennaioEs3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //chiedo al utente la lunghezza del array
            Console.WriteLine("Inserisci la lunghezza dell'array: \n");
            int DimensioneArray = Convert.ToInt16(Console.ReadLine());

            //creo l'array
            int[] myArray = new int[DimensioneArray];

            //utilizzo un loop per assegnare ad ogni index un valore
            for (int i = 0; i < DimensioneArray; i++)
            {
                Console.WriteLine($"Inserisci il valore di {i + 1}: ");
                myArray[i] = Convert.ToInt16(Console.ReadLine());
            }

            //somma di tutti i numeri
            int somma = 0;
            foreach (int numero in myArray)
            {
                somma += numero;
            }
            Console.WriteLine("La somma: " + somma);

            //calcolo della media
            double media = (double)somma / DimensioneArray;
            Console.WriteLine("La media: " + media);
            Console.ReadLine();
        }
    }
}
